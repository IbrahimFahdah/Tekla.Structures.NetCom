﻿using System;

namespace MyLibrary
{
    public class Class
    {
    }
}
